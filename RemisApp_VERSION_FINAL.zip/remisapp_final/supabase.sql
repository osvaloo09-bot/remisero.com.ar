-- ════════════════════════════════════════════════
--   REMISAPP — SQL PARA SUPABASE
--   Copiá todo esto en SQL Editor → New Query → Run
-- ════════════════════════════════════════════════

-- 1. USUARIOS
CREATE TABLE IF NOT EXISTS usuarios (
  id            uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre        text NOT NULL,
  usuario       text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  rol           text CHECK (rol IN ('admin','chofer','dueno')) NOT NULL,
  activo        boolean DEFAULT true,
  vence_hasta   date,
  num_sorteo    text,
  auto_id       uuid,
  telefono      text,
  num_turno     integer DEFAULT 1,
  creado_en     timestamp DEFAULT now()
);

-- 2. AUTOS
CREATE TABLE IF NOT EXISTS autos (
  id               uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  dueno_id         uuid REFERENCES usuarios(id) ON DELETE SET NULL,
  patente          text,
  modelo           text,
  turno_compartido boolean DEFAULT false,
  creado_en        timestamp DEFAULT now()
);

-- 3. TURNOS
CREATE TABLE IF NOT EXISTS turnos (
  id                 uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  chofer_id          uuid REFERENCES usuarios(id) ON DELETE SET NULL,
  auto_id            uuid REFERENCES autos(id) ON DELETE SET NULL,
  num_turno          integer DEFAULT 1,
  fecha_inicio       timestamp DEFAULT now(),
  fecha_cierre       timestamp,
  total_viajes       numeric DEFAULT 0,
  monto_chofer       numeric DEFAULT 0,
  monto_agencia      numeric DEFAULT 0,
  monto_dueno_bruto  numeric DEFAULT 0,
  total_combustible  numeric DEFAULT 0,
  total_gastos       numeric DEFAULT 0,
  monto_dueno_neto   numeric DEFAULT 0,
  cerrado            boolean DEFAULT false
);

-- 4. REGISTROS (viajes, combustible, gastos chicos)
CREATE TABLE IF NOT EXISTS registros (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  turno_id    uuid REFERENCES turnos(id) ON DELETE CASCADE,
  tipo        text CHECK (tipo IN ('viaje','combustible','gasto')) NOT NULL,
  monto       numeric NOT NULL,
  descripcion text,
  forma_pago  text DEFAULT '—',
  estacion    text,
  hora        timestamp DEFAULT now()
);

-- 5. RESERVAS (viajes con alerta programada)
CREATE TABLE IF NOT EXISTS reservas (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  chofer_id   uuid REFERENCES usuarios(id) ON DELETE CASCADE,
  descripcion text NOT NULL,
  hora_alerta timestamp NOT NULL,
  monto_est   numeric DEFAULT 0,
  completado  boolean DEFAULT false,
  creado_en   timestamp DEFAULT now()
);

-- 6. VIAJES PROGRAMADOS (fijos recurrentes)
CREATE TABLE IF NOT EXISTS programados (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  chofer_id   uuid REFERENCES usuarios(id) ON DELETE CASCADE,
  descripcion text NOT NULL,
  hora        time NOT NULL,
  monto_hab   numeric DEFAULT 0,
  activo      boolean DEFAULT true,
  creado_en   timestamp DEFAULT now()
);

-- 7. SORTEOS (historial mensual)
CREATE TABLE IF NOT EXISTS sorteos (
  id              uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  mes             text NOT NULL,
  numero_ganador  text,
  ganador_id      uuid REFERENCES usuarios(id) ON DELETE SET NULL,
  premio          text,
  fecha           timestamp DEFAULT now()
);

-- ════════════════════════════════════════════════
--   USUARIO ADMINISTRADOR INICIAL
--   Cambiá la contraseña antes de subir a producción
-- ════════════════════════════════════════════════
INSERT INTO usuarios (nombre, usuario, password_hash, rol, activo, num_sorteo)
VALUES ('Administrador', 'admin', 'admin123', 'admin', true, null)
ON CONFLICT (usuario) DO NOTHING;

-- ════════════════════════════════════════════════
--   USUARIOS DE PRUEBA (borrá esto en producción)
-- ════════════════════════════════════════════════
INSERT INTO usuarios (nombre, usuario, password_hash, rol, activo, vence_hasta, num_sorteo, num_turno)
VALUES
  ('Carlos Pérez',  'demo',    'demo',  'chofer', true, '2026-12-31', '047', 2),
  ('Roberto Díaz',  'chofer2', '1234',  'chofer', true, '2026-12-31', '182', 1),
  ('Miguel Torres', 'dueno1',  'dueno', 'dueno',  true, '2026-12-31', '315', 0)
ON CONFLICT (usuario) DO NOTHING;
